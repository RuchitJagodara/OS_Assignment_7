#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// A simple CPU-bound task that just burns CPU cycles
void
cpu_task(int iterations)
{
  int i, j, dummy = 0;

  for(i = 0; i < iterations; i++) {
    for(j = 0; j < 1000000; j++) {
      dummy += j;
    }
  }
}

// Test that higher priority processes get more CPU time
void test_priority_cpu_distribution() {
  int pids[3];
  int priorities[3] = {1, 10, 20}; // Low, medium, high priority
  int completion_order[3];
  int completion_count = 0;

  printf("\n=== Test: Priority CPU Distribution ===\n");
  printf("This test creates 3 CPU-bound processes with different priorities.\n");
  printf("Higher priority processes should complete faster.\n");

  // Make sure we're using the lottery scheduler
  setScheduler(1);

  // Create 3 child processes with different priorities
  for(int i = 0; i < 3; i++) {
    pids[i] = fork();
    if(pids[i] < 0) {
      printf("Fork failed\n");
      exit(1);
    } else if(pids[i] == 0) {
      // Child process
      int child_pid = getpid();
      int priority = priorities[i];

      // Print initial info
      printf("Child %d (PID %d) starting with priority %d\n", i, child_pid, priority);

      // Run CPU-bound task
      cpu_task(5); // All processes do the same amount of work

      printf("Child %d (PID %d) with priority %d completed\n", i, child_pid, priority);
      exit(i); // Exit with index as status
    } else {
      // Parent process - set priority for child
      printf("Setting priority of child %d (PID %d) to %d\n", i, pids[i], priorities[i]);
      setPriority(pids[i], priorities[i]);
    }
  }

  // Wait for all children to exit and record completion order
  for(int i = 0; i < 3; i++) {
    int status;
    int pid = wait(&status);

    // Find which child this was
    for(int j = 0; j < 3; j++) {
      if(pid == pids[j]) {
        completion_order[completion_count++] = j;
        printf("Child %d (priority %d) finished in position %d\n",
               j, priorities[j], completion_count);
        break;
      }
    }
  }

  // Check if higher priority processes finished first
  if(priorities[completion_order[0]] > priorities[completion_order[1]] &&
     priorities[completion_order[1]] > priorities[completion_order[2]]) {
    printf("PASS: Higher priority processes finished first\n");
  } else {
    printf("NOTE: Completion order doesn't strictly follow priorities.\n");
    printf("This is expected occasionally due to the probabilistic nature of lottery scheduling.\n");
  }
}

// Test that tickets are proportional to priority
void test_ticket_distribution() {
  int pids[5];
  int priorities[5] = {0, 5, 10, 15, 20};
  int expected_tickets[5] = {1, 6, 11, 16, 20}; // Based on formula: tickets = 1 + priority (capped at 20)

  printf("\n=== Test: Ticket Distribution ===\n");

  // Create 5 child processes with different priorities
  for(int i = 0; i < 5; i++) {
    pids[i] = fork();
    if(pids[i] < 0) {
      printf("Fork failed\n");
      exit(1);
    } else if(pids[i] == 0) {
      // Child process - just sleep and exit
      sleep(10);
      exit(0);
    } else {
      // Parent process - set priority for child
      setPriority(pids[i], priorities[i]);
      printf("Set priority of child %d (PID %d) to %d (expected tickets: %d)\n",
             i, pids[i], priorities[i], expected_tickets[i]);
    }
  }

  // Wait for all children to exit
  for(int i = 0; i < 5; i++) {
    wait(0);
  }

  printf("All children exited\n");
}

// Test context switch counter
void test_context_switch_counter() {
  int pid;

  printf("\n=== Test: Context Switch Counter ===\n");
  printf("This test creates processes that force context switches.\n");
  printf("The system should print '330' after every 3 context switches.\n");

  pid = fork();
  if(pid < 0) {
    printf("Fork failed\n");
    exit(1);
  } else if(pid == 0) {
    // Child process - create more context switches
    for(int i = 0; i < 15; i++) {
      printf("Child working... (%d/15)\n", i+1);

      // Alternate between CPU work and sleep to cause context switches
      if(i % 2 == 0) {
        cpu_task(1);
      } else {
        sleep(5);
      }
    }
    exit(0);
  } else {
    // Parent process - also do some work to cause context switches
    for(int i = 0; i < 5; i++) {
      printf("Parent working... (%d/5)\n", i+1);
      sleep(10);
    }

    // Wait for child
    wait(0);
  }
}

// Test scheduler switching
void test_scheduler_switching() {
  printf("\n=== Test: Scheduler Switching ===\n");

  // Switch to round-robin
  printf("Setting scheduler to round-robin (type 0)\n");
  int result = setScheduler(0);
  if(result < 0) {
    printf("FAIL: Could not set scheduler to round-robin\n");
  } else {
    printf("PASS: Scheduler set to round-robin\n");
  }

  // Create some processes with round-robin
  int pid = fork();
  if(pid < 0) {
    printf("Fork failed\n");
  } else if(pid == 0) {
    // Child process
    printf("Child running under round-robin scheduler\n");
    cpu_task(2);
    exit(0);
  } else {
    // Parent process
    wait(0);
  }

  // Switch to lottery
  printf("Setting scheduler to lottery (type 1)\n");
  result = setScheduler(1);
  if(result < 0) {
    printf("FAIL: Could not set scheduler to lottery\n");
  } else {
    printf("PASS: Scheduler set to lottery\n");
  }

  // Create some processes with lottery scheduler
  pid = fork();
  if(pid < 0) {
    printf("Fork failed\n");
  } else if(pid == 0) {
    // Child process
    printf("Child running under lottery scheduler\n");
    cpu_task(2);
    exit(0);
  } else {
    // Parent process
    wait(0);
  }
}

// Test extreme cases
void test_extreme_cases() {
  printf("\n=== Test: Extreme Cases ===\n");

  // Test with many processes
  printf("Creating 10 processes with varying priorities...\n");

  int pids[10];
  for(int i = 0; i < 10; i++) {
    pids[i] = fork();
    if(pids[i] < 0) {
      printf("Fork failed\n");
      exit(1);
    } else if(pids[i] == 0) {
      // Child process - do minimal work and exit
      sleep(i * 2); // Stagger the exits
      exit(0);
    } else {
      // Parent - set priority based on index
      int priority = i * 2; // 0, 2, 4, ..., 18
      if(priority > 20) priority = 20;
      setPriority(pids[i], priority);
    }
  }

  // Wait for all children
  for(int i = 0; i < 10; i++) {
    wait(0);
  }

  printf("All 10 processes completed\n");
}

int
main(int argc, char *argv[])
{
  printf("===== COMPREHENSIVE SCHEDULER TESTS =====\n");

  // Run all tests
  test_priority_cpu_distribution();
  test_ticket_distribution();
  test_context_switch_counter();
  test_scheduler_switching();
  test_extreme_cases();

  printf("\n===== ALL SCHEDULER TESTS COMPLETED =====\n");
  exit(0);
}
