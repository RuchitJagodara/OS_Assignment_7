#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// Test if a process can set its own priority
void test_self_priority() {
  int pid = getpid();
  int original_priority = getPriority(pid);

  printf("\n=== Test: Self Priority ===\n");
  printf("Current process (PID %d) has priority: %d\n", pid, original_priority);

  // Try to set own priority
  int result = setPriority(pid, 10);
  if(result < 0) {
    printf("PASS: Process cannot set its own priority\n");
  } else {
    printf("FAIL: Process should not be able to set its own priority\n");
  }

  // Verify priority didn't change
  int new_priority = getPriority(pid);
  if(new_priority == original_priority) {
    printf("PASS: Priority remained unchanged at %d\n", new_priority);
  } else {
    printf("FAIL: Priority changed from %d to %d\n", original_priority, new_priority);
  }
}

// Test setting invalid priority values
void test_invalid_priority() {
  int pid;

  printf("\n=== Test: Invalid Priority Values ===\n");

  pid = fork();
  if(pid < 0) {
    printf("Fork failed\n");
    exit(1);
  } else if(pid == 0) {
    // Child process - just sleep and exit
    sleep(20);
    exit(0);
  } else {
    // Parent process - try to set invalid priorities
    printf("Testing negative priority...\n");
    int result = setPriority(pid, -5);
    if(result < 0) {
      printf("PASS: Cannot set negative priority\n");
    } else {
      printf("FAIL: Should not allow negative priority\n");
    }

    printf("Testing too high priority...\n");
    result = setPriority(pid, 25);
    if(result < 0) {
      printf("PASS: Cannot set priority > 20\n");
    } else {
      printf("FAIL: Should not allow priority > 20\n");
    }

    // Clean up child
    wait(0);
  }
}

// Test setting priority for non-existent process
void test_nonexistent_process() {
  printf("\n=== Test: Non-existent Process ===\n");

  // Find a PID that doesn't exist (this is not foolproof but should work)
  int nonexistent_pid = 9999;

  int result = setPriority(nonexistent_pid, 10);
  if(result < 0) {
    printf("PASS: Cannot set priority for non-existent process\n");
  } else {
    printf("FAIL: Should not allow setting priority for non-existent process\n");
  }

  int priority = getPriority(nonexistent_pid);
  if(priority < 0) {
    printf("PASS: Cannot get priority for non-existent process\n");
  } else {
    printf("FAIL: Should not return priority for non-existent process\n");
  }
}

// Test priority inheritance during fork
void test_priority_inheritance() {
  int pid;
  int parent_priority;

  printf("\n=== Test: Priority Inheritance ===\n");

  // Get parent's priority before forking
  parent_priority = getPriority(getpid());

  // Create a child with parent's priority
  pid = fork();
  if(pid < 0) {
    printf("Fork failed\n");
    exit(1);
  } else if(pid == 0) {
    // Child process
    int child_pid = getpid();
    int child_priority = getPriority(child_pid);

    if(child_priority == parent_priority) {
      printf("PASS: Child inherited parent's priority (%d)\n", child_priority);
    } else {
      printf("FAIL: Child priority (%d) != Parent priority (%d)\n",
             child_priority, parent_priority);
    }

    exit(0);
  } else {
    // Parent process
    wait(0);
  }
}

// Test multiple children with different priorities
void test_multiple_children() {
  int pids[5];
  int priorities[5] = {1, 5, 10, 15, 20};

  printf("\n=== Test: Multiple Children with Different Priorities ===\n");

  // Create 5 children with different priorities
  for(int i = 0; i < 5; i++) {
    pids[i] = fork();
    if(pids[i] < 0) {
      printf("Fork failed\n");
      exit(1);
    } else if(pids[i] == 0) {
      // Child process
      int child_pid = getpid();

      // Sleep to allow parent to set priority
      sleep(10);

      // Get and print the priority
      int priority = getPriority(child_pid);
      printf("Child %d (PID %d) has priority: %d (expected: %d)\n",
             i, child_pid, priority, priorities[i]);

      if(priority == priorities[i]) {
        printf("PASS: Priority set correctly\n");
      } else {
        printf("FAIL: Priority not set correctly\n");
      }

      // Exit with child number as status
      exit(i);
    } else {
      // Parent process - set priority for child
      printf("Setting priority of child %d (PID %d) to %d\n",
             i, pids[i], priorities[i]);
      int result = setPriority(pids[i], priorities[i]);
      if(result < 0) {
        printf("FAIL: Could not set priority for PID %d\n", pids[i]);
      }
    }
  }

  // Wait for all children to exit
  for(int i = 0; i < 5; i++) {
    int status;
    int pid = wait(&status);
    printf("Child with PID %d exited with status %d\n", pid, status);
  }
}

// Test scheduler switching
void test_scheduler_switching() {
  printf("\n=== Test: Scheduler Switching ===\n");

  // Test invalid scheduler type
  printf("Testing invalid scheduler type...\n");
  int result = setScheduler(2);
  if(result < 0) {
    printf("PASS: Cannot set invalid scheduler type\n");
  } else {
    printf("FAIL: Should not allow invalid scheduler type\n");
  }

  // Switch to round-robin
  printf("Setting scheduler to round-robin (type 0)\n");
  result = setScheduler(0);
  if(result < 0) {
    printf("FAIL: Could not set scheduler to round-robin\n");
  } else {
    printf("PASS: Scheduler set to round-robin\n");
  }

  // Let the system run with round-robin for a bit
  sleep(20);

  // Switch to lottery
  printf("Setting scheduler to lottery (type 1)\n");
  result = setScheduler(1);
  if(result < 0) {
    printf("FAIL: Could not set scheduler to lottery\n");
  } else {
    printf("PASS: Scheduler set to lottery\n");
  }
}

int
main(int argc, char *argv[])
{
  printf("===== COMPREHENSIVE PRIORITY SYSTEM TESTS =====\n");

  // Run all tests
  test_self_priority();
  test_invalid_priority();
  test_nonexistent_process();
  test_priority_inheritance();
  test_multiple_children();
  test_scheduler_switching();

  printf("\n===== ALL TESTS COMPLETED =====\n");
  exit(0);
}
